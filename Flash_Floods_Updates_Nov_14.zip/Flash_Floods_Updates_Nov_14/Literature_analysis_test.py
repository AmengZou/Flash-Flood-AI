import os
from openai import OpenAI
from PyPDF2 import PdfReader

# === 1. Initialize API client ===
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

# === 2. Define literature directory ===
pdf_folder = r"C:\Users\amengzou\Desktop\2025_Fall\Collaboration_Flash_Flood\Review_FlashFlood_Flashiness"

# === 3. Output file path ===
output_file = os.path.join(pdf_folder, "FlashFlood_References_Extracted_APA.txt")

# === 4. Model pricing (USD per million tokens) ===
# GPT-4.1-mini official pricing (input/output)
INPUT_COST = 1.25 / 1_000_000     # $ per input token
OUTPUT_COST = 10 / 1_000_000    # $ per output token

# === 5. PDF text extraction ===
def extract_text_from_pdf(pdf_path, max_chars=8000):
    reader = PdfReader(pdf_path)
    text = ""
    for page in reader.pages:
        text += page.extract_text() or ""
        if len(text) > max_chars:
            break
    return text[:max_chars]

# === 6. Main loop ===
results = []
total_input_tokens = 0
total_output_tokens = 0

for filename in os.listdir(pdf_folder):
    if filename.lower().endswith(".pdf"):
        pdf_path = os.path.join(pdf_folder, filename)
        print(f"Analyzing: {filename}")

        text = extract_text_from_pdf(pdf_path)

        prompt = f"""
I am an academic researcher. Carefully read the following paper text,
identify the references in this document that are related to "Flash Flood",
and output those references in **APA format**.

APA format example:
Smith, J. A., & Doe, R. B. (2021). Flash flood prediction using radar data. *Journal of Hydrology, 593*(4), 125–138.*

Paper content:
{text}
"""

        # === Call GPT model ===
        response = client.chat.completions.create(
            model="gpt-5",
            messages=[
                {"role": "system", "content": "You are a helpful research assistant."},
                {"role": "user", "content": prompt}
            ]
        )

        extracted_refs = response.choices[0].message.content.strip()

        # === Record token usage ===
        usage = response.usage
        input_tokens = usage.prompt_tokens
        output_tokens = usage.completion_tokens

        total_input_tokens += input_tokens
        total_output_tokens += output_tokens

        # === Append results ===
        results.append(
            f"{filename}\n"
            f"{extracted_refs}\n"
            f"Tokens used: input {input_tokens}, output {output_tokens}\n"
            f"{'-'*80}\n"
        )

# === 7. Save results ===
with open(output_file, "w", encoding="utf-8") as f:
    f.writelines(results)

# === 8. Compute total cost ===
input_cost_usd = total_input_tokens * INPUT_COST
output_cost_usd = total_output_tokens * OUTPUT_COST
total_cost_usd = input_cost_usd + output_cost_usd

print("\nAnalysis completed. Results saved to:", output_file)
print("Token usage summary:")
print(f"    Total input tokens: {total_input_tokens:,}")
print(f"    Total output tokens: {total_output_tokens:,}")
print(f"    Estimated total cost: ${total_cost_usd:.6f} USD")
